:HL["/_next/static/chunks/14z1fl0704tre.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"onboarding","param":null,"prefetchHints":0,"slots":{"children":{"name":"artisan","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"HD_Wb-3epFkI2JxAulwSf"}
