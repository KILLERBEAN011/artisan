var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__0-yg41a._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_route_actions_1x10bx0.js")
R.m(35578)
module.exports=R.m(35578).exports
