var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/messages/route.js")
R.c("server/chunks/[root-of-the-server]__09z1-i_._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/[root-of-the-server]__1hq7k8g._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_messages_route_actions_11dtnyp.js")
R.m(34425)
module.exports=R.m(34425).exports
