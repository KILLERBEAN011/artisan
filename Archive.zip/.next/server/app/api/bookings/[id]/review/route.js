var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/review/route.js")
R.c("server/chunks/[root-of-the-server]__1m6qq3p._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_review_route_actions_0atrtaj.js")
R.m(27671)
module.exports=R.m(27671).exports
