var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__00u6zim._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_route_actions_1h9a10_.js")
R.m(15899)
module.exports=R.m(15899).exports
