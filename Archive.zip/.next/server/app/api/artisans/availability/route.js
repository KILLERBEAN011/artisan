var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/artisans/availability/route.js")
R.c("server/chunks/[root-of-the-server]__1q9fc_r._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_artisans_availability_route_actions_1rbzqqa.js")
R.m(13144)
module.exports=R.m(13144).exports
