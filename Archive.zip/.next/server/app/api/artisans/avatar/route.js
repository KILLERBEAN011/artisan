var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/artisans/avatar/route.js")
R.c("server/chunks/[root-of-the-server]__0ds3exl._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_artisans_avatar_route_actions_1uk4i-l.js")
R.m(1329)
module.exports=R.m(1329).exports
