var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/artisans/bank-details/route.js")
R.c("server/chunks/[root-of-the-server]__02e7rkv._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_artisans_bank-details_route_actions_0nlv6je.js")
R.m(55636)
module.exports=R.m(55636).exports
