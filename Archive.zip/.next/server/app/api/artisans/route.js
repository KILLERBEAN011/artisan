var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/artisans/route.js")
R.c("server/chunks/[root-of-the-server]__13b48c9._.js")
R.c("server/chunks/_030-wuc._.js")
R.c("server/chunks/_0o0ouha._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_artisans_route_actions_1-cjzo9.js")
R.m(10620)
module.exports=R.m(10620).exports
