module.exports=[58360,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artisans_availability_route_actions_1rbzqqa.js.map