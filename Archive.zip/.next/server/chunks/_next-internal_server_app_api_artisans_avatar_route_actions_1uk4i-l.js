module.exports=[8127,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artisans_avatar_route_actions_1uk4i-l.js.map