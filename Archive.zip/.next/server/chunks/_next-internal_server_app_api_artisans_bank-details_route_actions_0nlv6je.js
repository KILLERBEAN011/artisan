module.exports=[83219,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artisans_bank-details_route_actions_0nlv6je.js.map