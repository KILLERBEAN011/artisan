module.exports=[52380,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artisans_route_actions_1-cjzo9.js.map