module.exports=[74338,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bookings_%5Bid%5D_review_route_actions_0atrtaj.js.map