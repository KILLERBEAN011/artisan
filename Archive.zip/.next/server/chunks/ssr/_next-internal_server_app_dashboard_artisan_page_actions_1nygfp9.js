module.exports=[26227,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_artisan_page_actions_1nygfp9.js.map