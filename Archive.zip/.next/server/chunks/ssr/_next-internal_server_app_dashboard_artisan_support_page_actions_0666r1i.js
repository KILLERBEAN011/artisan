module.exports=[16600,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_artisan_support_page_actions_0666r1i.js.map