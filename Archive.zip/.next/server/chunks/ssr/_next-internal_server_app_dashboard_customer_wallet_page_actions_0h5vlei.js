module.exports=[6502,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_customer_wallet_page_actions_0h5vlei.js.map