module.exports=[85679,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_artisan_verification_page_actions_0x3n-6-.js.map