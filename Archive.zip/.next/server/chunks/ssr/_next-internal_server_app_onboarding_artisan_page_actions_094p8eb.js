module.exports=[82194,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_onboarding_artisan_page_actions_094p8eb.js.map