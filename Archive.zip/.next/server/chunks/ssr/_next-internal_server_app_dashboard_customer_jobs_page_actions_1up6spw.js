module.exports=[40891,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_customer_jobs_page_actions_1up6spw.js.map