module.exports=[86174,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_customer_reviews_page_actions_0b5zduv.js.map