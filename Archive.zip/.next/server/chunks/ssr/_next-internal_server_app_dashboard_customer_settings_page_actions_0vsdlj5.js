module.exports=[87491,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_customer_settings_page_actions_0vsdlj5.js.map