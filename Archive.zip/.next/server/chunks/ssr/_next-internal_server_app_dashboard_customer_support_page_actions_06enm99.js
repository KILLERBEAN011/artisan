module.exports=[71307,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_customer_support_page_actions_06enm99.js.map