module.exports=[98384,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_artisans_%5Bid%5D_page_actions_00-j0d_.js.map