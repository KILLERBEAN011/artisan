module.exports=[69066,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_artisan_reviews_page_actions_1jwmdf_.js.map