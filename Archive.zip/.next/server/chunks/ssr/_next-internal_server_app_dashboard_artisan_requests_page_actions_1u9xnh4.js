module.exports=[43863,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_artisan_requests_page_actions_1u9xnh4.js.map