globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/HD_Wb-3epFkI2JxAulwSf/_buildManifest.js",
    "static/HD_Wb-3epFkI2JxAulwSf/_ssgManifest.js",
    "static/HD_Wb-3epFkI2JxAulwSf/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3dctyoflmz296.js",
    "static/chunks/1cic2vlu0tna9.js",
    "static/chunks/37rv6iqgkbd3d.js",
    "static/chunks/10lzwjioi-7jo.js",
    "static/chunks/turbopack-2117tdz0ozejy.js"
  ]
};
